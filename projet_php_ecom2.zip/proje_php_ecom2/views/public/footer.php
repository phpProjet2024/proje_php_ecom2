<p style="text-align:center ; background-color:red">Je suis le footer</p>

